# Security Policy

Notespice is a personal, single-maintainer project, not a company or a
team with a dedicated security function. This document sets realistic
expectations rather than promising something that isn't true.

## Supported versions

Only the latest release (the `latest` tag / most recent tagged commit) is
supported. There's no long-term-support branch and no backporting of
fixes to older versions: if a vulnerability is found, the fix lands in
the next build, and you're expected to update to it.

## Reporting a vulnerability

**Please don't put the details of a security vulnerability in a public
bug report.** A public report discloses the problem to everyone,
including anyone running an unpatched copy, before a fix exists.

Write to <complaints@lightmorphic.com> with "Notespice security"
in the subject line and say only that you have a security issue to
report. Leave the details out of that first message. The maintainer will
reply and arrange a private channel for the rest.

There is no public bug tracker for this project, so there is nothing you
could post publicly by accident.

## What to expect

This is maintained in whatever time is available outside other
commitments, not on an SLA. Best-effort, not guaranteed:
- Acknowledgement of a report: aim for a few days
- A fix or mitigation: depends entirely on severity and complexity.
  Could be same-day for something simple and serious, could be longer
  for something subtle

## Scope

This policy covers the Notespice application code itself: the Rust
backend, the frontend and the Dockerfile. It does not cover:
- Vulnerabilities in dependencies themselves (report those upstream, to
  the dependency's own maintainers or via [RustSec](https://rustsec.org/))
- Your own deployment environment (reverse proxy config, TLS setup,
  network exposure, host OS); those are outside this project's control

## What's already in place

For context on the existing security posture (so a report can focus on
what's actually new), see the **Security notes** section in
[README.md](./README.md), which is also on the website at
<https://notespice.org/docs>. Briefly: Argon2id password hashing,
server-side session tokens, per-IP login rate limiting, allow-list
filename sanitisation against path traversal, a non-root container user,
OS packages patched at every build, and a capped request body size.
